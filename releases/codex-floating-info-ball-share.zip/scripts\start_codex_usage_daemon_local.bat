@echo off
cd /d "%~dp0\.."
set CODEX_USAGE_SOURCE=codex_sessions
start "" /min pythonw "src\codex_bubble\codex_usage_daemon.py"
